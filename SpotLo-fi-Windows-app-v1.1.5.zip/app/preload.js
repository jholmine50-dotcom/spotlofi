// Ponte entre a página e o app (mesma interface usada no Mac)
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('__SPOTLOFI_APP__', { version: '1.1.2', os: 'win' });
contextBridge.exposeInMainWorld('webkit', {
  messageHandlers: {
    spotlofi: { postMessage: (msg) => ipcRenderer.send('cmd', msg) }
  }
});
