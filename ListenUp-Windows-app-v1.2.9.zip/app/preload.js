// Ponte entre a página e o app (mesma interface usada no Mac)
const { contextBridge, ipcRenderer } = require('electron');

let version = '';
try { version = ipcRenderer.sendSync('appVersion') || ''; } catch (e) {}
contextBridge.exposeInMainWorld('__SPOTLOFI_APP__', { version, os: 'win' });
contextBridge.exposeInMainWorld('webkit', {
  messageHandlers: {
    spotlofi: { postMessage: (msg) => ipcRenderer.send('cmd', msg) }
  }
});
