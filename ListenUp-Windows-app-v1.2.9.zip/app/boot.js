// SpotLo-fi para Windows — inicialização
// Escolhe qual versão abrir: a que veio com o instalador ou uma atualização baixada depois
// (as atualizações ficam em %APPDATA%\SpotLo-fi\updates\<versão>, sem mexer nos arquivos do programa).
const path = require('path');
const fs = require('fs');
const { app } = require('electron');

app.setName('SpotLo-fi');
const cmp = (a, b) => {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0), pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x > y ? 1 : -1; }
  return 0;
};
const bundledMain = path.join(__dirname, 'main.js');
let target = bundledMain;
try {
  const bundled = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version;
  const root = path.join(app.getPath('userData'), 'updates');
  let bestV = bundled;
  for (const d of fs.existsSync(root) ? fs.readdirSync(root) : []) {
    const dir = path.join(root, d);
    try {
      if (!fs.existsSync(path.join(dir, 'main.js')) || fs.existsSync(path.join(dir, '.bad'))) continue;
      const v = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version;
      if (cmp(v, bestV) > 0) { bestV = v; target = path.join(dir, 'main.js'); }
    } catch (e) {}
  }
  // apaga atualizações antigas que não vão mais ser usadas
  for (const d of fs.existsSync(root) ? fs.readdirSync(root) : []) {
    const dir = path.join(root, d);
    if (path.join(dir, 'main.js') === target) continue;
    let v = '';
    try { v = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version; } catch (e) {}
    if (d === 'baixando' || !v || cmp(v, bestV) < 0) { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {} }
  }
} catch (e) {}

try {
  require(target);
} catch (e) {
  if (target === bundledMain) throw e;
  // a atualização não abriu: marca como ruim e volta para a versão instalada
  try { fs.writeFileSync(path.join(path.dirname(target), '.bad'), String((e && e.stack) || e)); } catch (_) {}
  require(bundledMain);
}
