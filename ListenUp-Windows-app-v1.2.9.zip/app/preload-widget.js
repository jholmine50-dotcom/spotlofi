const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('webkit', {
  messageHandlers: {
    widget: { postMessage: (msg) => ipcRenderer.send('widget', msg) }
  }
});
