﻿# SpotLo-fi — monitor de áudio do Windows
# Lista, a cada meio segundo, quais programas estão tocando som (sessões de áudio ativas com volume real).
# Não grava nem escuta nada: só lê o "medidor de pico" que o próprio Windows mostra no Mixer de Volume.
$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace SpotLoFi {
  [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCo {}

  [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDeviceEnumerator {
    [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
    [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
  }

  [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDevice {
    [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
  }

  [Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IAudioSessionManager2 {
    [PreserveSig] int GetAudioSessionControl(IntPtr a, int b, out IntPtr c);
    [PreserveSig] int GetSimpleAudioVolume(IntPtr a, int b, out IntPtr c);
    [PreserveSig] int GetSessionEnumerator(out IAudioSessionEnumerator sessionEnum);
  }

  [Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IAudioSessionEnumerator {
    [PreserveSig] int GetCount(out int count);
    [PreserveSig] int GetSession(int index, out IAudioSessionControl2 session);
  }

  [Guid("bfb7ff88-7239-4fc9-8fa2-07c950be9c6d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IAudioSessionControl2 {
    [PreserveSig] int GetState(out int state);
    [PreserveSig] int GetDisplayName(out IntPtr name);
    [PreserveSig] int SetDisplayName(IntPtr a, IntPtr b);
    [PreserveSig] int GetIconPath(out IntPtr path);
    [PreserveSig] int SetIconPath(IntPtr a, IntPtr b);
    [PreserveSig] int GetGroupingParam(out Guid g);
    [PreserveSig] int SetGroupingParam(IntPtr a, IntPtr b);
    [PreserveSig] int RegisterAudioSessionNotification(IntPtr a);
    [PreserveSig] int UnregisterAudioSessionNotification(IntPtr a);
    [PreserveSig] int GetSessionIdentifier(out IntPtr id);
    [PreserveSig] int GetSessionInstanceIdentifier(out IntPtr id);
    [PreserveSig] int GetProcessId(out uint pid);
    [PreserveSig] int IsSystemSoundsSession();
  }

  [Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IAudioMeterInformation {
    [PreserveSig] int GetPeakValue(out float peak);
  }

  public static class Monitor {
    public static string Snapshot() {
      var items = new List<string>();
      IMMDeviceEnumerator en = null;
      try {
        en = (IMMDeviceEnumerator)(new MMDeviceEnumeratorCo());
        IMMDevice dev;
        if (en.GetDefaultAudioEndpoint(0, 1, out dev) != 0 || dev == null) return "[]";   // eRender, eMultimedia
        Guid iid = typeof(IAudioSessionManager2).GUID;
        object o;
        if (dev.Activate(ref iid, 23, IntPtr.Zero, out o) != 0) return "[]";               // CLSCTX_ALL
        var mgr = (IAudioSessionManager2)o;
        IAudioSessionEnumerator sessions;
        if (mgr.GetSessionEnumerator(out sessions) != 0) return "[]";
        int count; sessions.GetCount(out count);
        for (int i = 0; i < count; i++) {
          IAudioSessionControl2 s;
          if (sessions.GetSession(i, out s) != 0 || s == null) continue;
          try {
            int state; s.GetState(out state);
            if (state != 1) continue;                       // só sessões ativas
            if (s.IsSystemSoundsSession() == 0) continue;   // ignora sons do sistema
            uint pid; s.GetProcessId(out pid);
            float peak = 0;
            var meter = s as IAudioMeterInformation;
            if (meter != null) meter.GetPeakValue(out peak);
            if (peak < 0.0005f) continue;                   // aberto mas em silêncio
            string name = "";
            try { name = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName; } catch {}
            name = name.Replace("\\", "").Replace("\"", "");
            items.Add("{\"pid\":" + pid + ",\"app\":\"" + name + "\",\"peak\":" + peak.ToString(System.Globalization.CultureInfo.InvariantCulture) + "}");
          } finally { Marshal.ReleaseComObject(s); }
        }
        Marshal.ReleaseComObject(sessions);
        Marshal.ReleaseComObject(mgr);
        Marshal.ReleaseComObject(dev);
      } catch { return "[]"; }
      finally { if (en != null) Marshal.ReleaseComObject(en); }
      return "[" + string.Join(",", items) + "]";
    }
  }
}
"@

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
while ($true) {
  try { [Console]::Out.WriteLine([SpotLoFi.Monitor]::Snapshot()); [Console]::Out.Flush() } catch { [Console]::Out.WriteLine("[]") }
  Start-Sleep -Milliseconds 500
}
