#!/bin/bash
# Monta o SpotLo-fi.app a partir desta pasta e instala em Aplicativos.
# Uso:  bash build-app.sh
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="SpotLo-fi"
BUNDLE_ID="com.spotlofi.app"
VERSION="1.1.6"
OUT="build/$APP_NAME.app"

for f in main.swift extras.swift app112.swift SpotLo-fi.html; do
  [ -f "$f" ] || { echo "Falta o arquivo $f nesta pasta."; exit 1; }
done

if ! xcode-select -p >/dev/null 2>&1; then
  echo "Falta o compilador da Apple (Command Line Tools). Vou abrir o instalador."
  echo "Quando ele terminar, rode este script de novo."
  xcode-select --install || true
  exit 0
fi

echo "▸ Preparando o app…"
rm -rf build
mkdir -p "$OUT/Contents/MacOS" "$OUT/Contents/Resources"

echo "▸ Compilando (leva uns segundos)…"
ARCH="$(uname -m)"
SDK="$(xcrun --show-sdk-path)"
FM_FLAGS=()
if [ -d "$SDK/System/Library/Frameworks/FoundationModels.framework" ]; then
  FM_FLAGS=(-D HAS_FM -Xlinker -weak_framework -Xlinker FoundationModels)
  echo "  (com Apple Intelligence)"
else
  echo "  (aviso: este compilador não tem o Apple Intelligence; atualize as Command Line Tools para usar a IA)"
fi
compile() {
  xcrun swiftc -O -swift-version 5 \
    -target "$ARCH-apple-macos13.0" \
    -framework Cocoa -framework WebKit -framework CoreAudio -framework Network \
    -framework MediaPlayer -framework ServiceManagement -framework UniformTypeIdentifiers \
    -framework Carbon -framework Speech -framework AVFoundation \
    "$@" \
    main.swift extras.swift app112.swift -o "$OUT/Contents/MacOS/$APP_NAME"
}
if [ ${#FM_FLAGS[@]} -gt 0 ]; then
  if ! compile "${FM_FLAGS[@]}" 2> build/compile-ai.log; then
    echo "  (aviso: a parte do Apple Intelligence não compilou; montando sem ela. Detalhes: $(pwd)/build/compile-ai.log)"
    compile
  fi
else
  compile
fi

cp SpotLo-fi.html "$OUT/Contents/Resources/index.html"
[ -f StatusIcon.png ] && cp StatusIcon.png "$OUT/Contents/Resources/StatusIcon.png"
[ -f widget.html ] && cp widget.html "$OUT/Contents/Resources/widget.html" && chmod 644 "$OUT/Contents/Resources/widget.html"
chmod 644 "$OUT/Contents/Resources/index.html"

if [ -f icon.png ]; then
  echo "▸ Criando o ícone…"
  ICONSET="build/AppIcon.iconset"
  mkdir -p "$ICONSET"
  for s in 16 32 128 256 512; do
    sips -z $s $s icon.png --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
    d=$((s*2))
    sips -z $d $d icon.png --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns "$ICONSET" -o "$OUT/Contents/Resources/AppIcon.icns"
fi

cat > "$OUT/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>$APP_NAME</string>
  <key>CFBundleDisplayName</key><string>$APP_NAME</string>
  <key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
  <key>CFBundleExecutable</key><string>$APP_NAME</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.music</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSPrincipalClass</key><string>NSApplication</string>
  <key>NSHumanReadableCopyright</key><string>SpotLo-fi</string>
  <key>NSMicrophoneUsageDescription</key><string>O SpotLo-fi usa o microfone para ouvir seus comandos de voz e para as chamadas do Estudar junto.</string>
  <key>NSSpeechRecognitionUsageDescription</key><string>O SpotLo-fi transforma sua voz em comandos para a IA do app.</string>
  <key>CFBundleURLTypes</key>
  <array>
    <dict>
      <key>CFBundleURLName</key><string>SpotLo-fi</string>
      <key>CFBundleURLSchemes</key><array><string>spotlofi</string></array>
    </dict>
  </array>
  <key>NSAppTransportSecurity</key>
  <dict>
    <key>NSAllowsLocalNetworking</key><true/>
    <key>NSAllowsArbitraryLoadsInWebContent</key><true/>
  </dict>
</dict>
</plist>
EOF

echo "▸ Assinando (assinatura local)…"
codesign --force --deep --sign - "$OUT" >/dev/null 2>&1 || echo "  (aviso: não consegui assinar, mas o app deve abrir mesmo assim)"

# Para de rodar uma versão antiga, se estiver aberta
osascript -e 'tell application "SpotLo-fi" to quit' >/dev/null 2>&1 || true
for _ in $(seq 1 20); do
  pgrep -x "SpotLo-fi" >/dev/null 2>&1 || break
  sleep 0.5
done

# As playlists ficam fora do app (não são apagadas ao reinstalar), mas guardo uma cópia por garantia
DATA="$HOME/Library/WebKit/com.spotlofi.app"
if [ -d "$DATA" ]; then
  BK="$HOME/Library/Application Support/SpotLo-fi/backup-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BK" && cp -R "$DATA" "$BK/" 2>/dev/null && echo "▸ Backup das suas playlists salvo em: $BK"
fi

DEST="/Applications"
if [ ! -w "$DEST" ]; then DEST="$HOME/Applications"; mkdir -p "$DEST"; fi
rm -rf "$DEST/$APP_NAME.app"
cp -R "$OUT" "$DEST/"

# O app já faz o trabalho do ajudante antigo; se ele estiver instalado, desliga
OLD="$HOME/Library/LaunchAgents/com.spotlofi.ducker.plist"
if [ -f "$OLD" ]; then
  launchctl bootout "gui/$(id -u)" "$OLD" 2>/dev/null || true
  rm -f "$OLD" "$HOME/Library/Application Support/SpotLo-fi/spotlofi-ducker"
  echo "▸ Removi o ajudante antigo (o app já faz isso sozinho)."
fi

echo ""
echo "✓ Pronto! SpotLo-fi instalado em $DEST. Abrindo…"
open "$DEST/$APP_NAME.app"
