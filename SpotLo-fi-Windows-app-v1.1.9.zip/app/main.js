// SpotLo-fi para Windows (sem IA)
// Janela do app, servidor local, ícone perto do relógio, teclas de mídia, atalhos globais,
// modo mini, widget, "abaixar quando outro programa tocar", links spotlofi://, backup e atualização.

const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, globalShortcut, dialog, shell, clipboard, session, screen, components } = require('electron');
const http = require('http');
const https = require('https');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, execFile } = require('child_process');

const APP_VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version; } catch (e) { return '0.0.0'; } })();
const UPDATE_REPO = 'jholmine50-dotcom/spotlofi';
const PORT_PREFERRED = 17846;          // a biblioteca fica guardada por endereço: mantenha a mesma porta
const DIR = __dirname;
const ICON = path.join(DIR, 'icon.ico');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

app.setName('SpotLo-fi');
app.setAppUserModelId('com.spotlofi.app');
app.userAgentFallback = UA;
// as teclas de mídia controlam a fila do SpotLo-fi (e não o player do YouTube por dentro)
app.commandLine.appendSwitch('disable-features', 'HardwareMediaKeyHandling');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

// ---------- uma instância só + links spotlofi:// ----------
let gotLock = app.requestSingleInstanceLock();
// logo depois de uma atualização a versão anterior pode levar um instante para fechar
if (!gotLock && process.argv.includes('--after-update')) {
  const t0 = Date.now(), pause = new Int32Array(new SharedArrayBuffer(4));
  while (!gotLock && Date.now() - t0 < 8000) { Atomics.wait(pause, 0, 0, 300); gotLock = app.requestSingleInstanceLock(); }
}
if (!gotLock) { app.quit(); process.exit(0); }
if (process.defaultApp) {
  app.setAsDefaultProtocolClient('spotlofi', process.execPath, [path.resolve(process.argv[1] || '.')]);
} else {
  app.setAsDefaultProtocolClient('spotlofi');
}

let win = null, widget = null, tray = null, port = 0;
let pageReady = false, pendingURLs = [];
let quitting = false;
let isMini = false, miniKind = 'yt', savedBounds = null;
let np = { title: '', artist: '', playing: false, thumb: '' };
let widgetState = {}, widgetOnTop = false;
let sceneNames = [];

const urlsFrom = (argv) => (argv || []).filter((a) => /^spotlofi:/i.test(a));
pendingURLs.push(...urlsFrom(process.argv));
app.on('second-instance', (_e, argv) => {
  showMain();
  for (const u of urlsFrom(argv)) handleURL(u);
});
function handleURL(u) { if (pageReady) toPage({ url: u }); else pendingURLs.push(u); }

// ---------- utilidades ----------
function toPage(msg) {
  if (!win || win.isDestroyed()) return;
  win.webContents.executeJavaScript(`window.spotlofiNative&&window.spotlofiNative(${JSON.stringify(msg)})`).catch(() => {});
}
function postURL(url, body, headers = {}) {
  return new Promise((resolve) => {
    let u; try { u = new URL(url); } catch (e) { return resolve(null); }
    const data = Buffer.from(body, 'utf8');
    const req = https.request(u, { method: 'POST', headers: { 'User-Agent': UA, 'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8', 'Content-Length': data.length, ...headers }, timeout: 20000 }, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) { res.resume(); return resolve(null); }
      const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('timeout', () => req.destroy()); req.on('error', () => resolve(null));
    req.end(data);
  });
}
function getURL(url, headers = {}, redirects = 5) {
  return new Promise((resolve) => {
    let u; try { u = new URL(url); } catch (e) { return resolve(null); }
    const lib = u.protocol === 'http:' ? http : https;
    const req = lib.get(u, { headers: { 'User-Agent': UA, 'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8', ...headers }, timeout: 15000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
        res.resume(); return resolve(getURL(new URL(res.headers.location, u).toString(), headers, redirects - 1));
      }
      if (res.statusCode < 200 || res.statusCode >= 300) { res.resume(); return resolve(null); }
      const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('timeout', () => req.destroy()); req.on('error', () => resolve(null));
  });
}
function postForm(url, body, headers) {
  return new Promise((resolve) => {
    const u = new URL(url);
    const req = https.request(u, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body), ...headers }, timeout: 15000 }, (res) => {
      const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', () => resolve(null)); req.write(body); req.end();
  });
}

// ---------- busca e importação (mesma lógica do app do Mac) ----------
function extractJSON(html, markers) {
  for (const m of markers) {
    const at = html.indexOf(m); if (at < 0) continue;
    let i = html.indexOf('{', at + m.length); if (i < 0) continue;
    const start = i; let depth = 0, inStr = false, esc = false;
    for (; i < html.length; i++) {
      const c = html[i];
      if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; }
      else if (c === '"') inStr = true;
      else if (c === '{') depth++;
      else if (c === '}') { depth--; if (depth === 0) { try { return JSON.parse(html.slice(start, i + 1)); } catch (e) { break; } } }
    }
  }
  return null;
}
function walk(v, fn) { if (Array.isArray(v)) v.forEach((x) => walk(x, fn)); else if (v && typeof v === 'object') { fn(v); for (const k in v) walk(v[k], fn); } }
const ytText = (v) => !v ? '' : typeof v === 'string' ? v : v.simpleText || v.content || (v.runs ? v.runs.map((r) => r.text).join('') : '');
function firstStr(v, test) { let f = null; walk(v, (d) => { if (f) return; for (const k in d) if (typeof d[k] === 'string' && test(k, d[k])) { f = d[k]; return; } }); return f; }

async function ytSearch(q, kind) {
  const u = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}&hl=pt-BR&gl=BR${kind === 'channel' ? '&sp=EgIQAg%253D%253D' : kind === 'playlist' ? '&sp=EgIQAw%253D%253D' : ''}`;
  const buf = await getURL(u, { Cookie: 'CONSENT=YES+1; SOCS=CAI' });
  const root = buf && extractJSON(buf.toString('utf8'), ['var ytInitialData = ', 'window["ytInitialData"] = ', 'ytInitialData = ']);
  if (!root) return { ok: false, error: 'Não consegui buscar no YouTube agora.' };
  const primary = (((root.contents || {}).twoColumnSearchResultsRenderer || {}).primaryContents) || root;
  const seen = new Set(), items = [];
  walk(primary, (d) => {
    if (items.length >= 30) return;
    const c = d.channelRenderer;
    if (c && c.channelId && !seen.has(c.channelId)) {
      seen.add(c.channelId);
      let th = firstStr(c.thumbnail || c, (k) => k === 'url') || ''; if (th.startsWith('//')) th = 'https:' + th;
      items.push({ type: 'channel', id: c.channelId, title: ytText(c.title), author: '', meta: [ytText(c.videoCountText), ytText(c.subscriberCountText)].filter((x) => x && !x.startsWith('@')).join(' · '), thumb: th });
    }
    const v = d.videoRenderer;
    if (v && v.videoId && !seen.has(v.videoId)) { seen.add(v.videoId); items.push({ type: 'video', id: v.videoId, title: ytText(v.title), author: ytText(v.ownerText), meta: ytText(v.lengthText), thumb: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg` }); }
    const p = d.playlistRenderer;
    if (p && p.playlistId && !seen.has(p.playlistId)) { seen.add(p.playlistId); items.push({ type: 'playlist', id: p.playlistId, title: ytText(p.title), author: ytText(p.shortBylineText || p.longBylineText), meta: p.videoCount ? `${p.videoCount} vídeos` : '', thumb: firstStr(p.thumbnails || p, (k, s) => k === 'url' && s.includes('ytimg')) || '' }); }
    const l = d.lockupViewModel;
    if (l && l.contentId && String(l.contentType || '').includes('PLAYLIST') && !seen.has(l.contentId)) {
      seen.add(l.contentId);
      const md = ((l.metadata || {}).lockupMetadataViewModel) || {};
      items.push({ type: 'playlist', id: l.contentId, title: ytText(md.title), author: firstStr(md.metadata || {}, (k) => k === 'content') || '', meta: 'Playlist', thumb: firstStr(l.contentImage || l, (k, s) => k === 'url' && s.includes('ytimg')) || '' });
    }
  });
  return { ok: true, items };
}
async function spEmbed(kind, id) {
  const buf = await getURL(`https://open.spotify.com/embed/${kind}/${id}`);
  if (!buf) return { ok: false, error: 'Não consegui ler essa playlist do Spotify.' };
  const html = buf.toString('utf8');
  const m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
  if (!m) return { ok: false };
  let root; try { root = JSON.parse(m[1]); } catch (e) { return { ok: false }; }
  let name = '', tracks = [];
  walk(root, (d) => {
    if (tracks.length || !Array.isArray(d.trackList) || !d.trackList.length) return;
    name = d.name || d.title || '';
    tracks = d.trackList.filter((t) => t.uri).map((t) => ({ uri: t.uri, title: t.title || '', artist: t.subtitle || '' }));
  });
  return { ok: tracks.length > 0, name, tracks };
}
let spToken = null;
async function spSearch(q, cid, cs) {
  const key = `${cid}:${cs}`;
  if (!spToken || spToken.key !== key || spToken.until < Date.now()) {
    const r = await postForm('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', { Authorization: 'Basic ' + Buffer.from(key).toString('base64') });
    let j = null; try { j = JSON.parse(r.toString()); } catch (e) {}
    if (!j || !j.access_token) return { ok: false, error: 'Client ID ou Secret do Spotify inválidos.' };
    spToken = { token: j.access_token, until: Date.now() + ((j.expires_in || 3000) - 60) * 1000, key };
  }
  const buf = await getURL(`https://api.spotify.com/v1/search?q=${encodeURIComponent(q)}&type=track,playlist,album&limit=10&market=BR`, { Authorization: `Bearer ${spToken.token}` });
  let root = null; try { root = JSON.parse(buf.toString()); } catch (e) {}
  if (!root) return { ok: false, error: 'O Spotify recusou a busca. Confira o Client ID e o Secret.' };
  const img = (a) => (Array.isArray(a) && a[0] && a[0].url) || '';
  const items = [];
  for (const t of ((root.tracks || {}).items || []).filter(Boolean)) {
    const ms = t.duration_ms || 0;
    items.push({ type: 'track', id: t.id, title: t.name, author: (t.artists || []).map((a) => a.name).join(', '), meta: `${Math.floor(ms / 60000)}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}`, thumb: img((t.album || {}).images) });
  }
  for (const p of ((root.playlists || {}).items || []).filter(Boolean)) items.push({ type: 'playlist', id: p.id, title: p.name, author: (p.owner || {}).display_name || '', meta: p.tracks ? `${p.tracks.total} músicas` : 'Playlist', thumb: img(p.images) });
  for (const a of ((root.albums || {}).items || []).filter(Boolean)) items.push({ type: 'album', id: a.id, title: a.name, author: (a.artists || []).map((x) => x.name).join(', '), meta: 'Álbum', thumb: img(a.images) });
  return { ok: true, items };
}
async function oembed(target) {
  const isSp = target.includes('spotify.com');
  const u = isSp ? `https://open.spotify.com/oembed?url=${encodeURIComponent(target)}` : `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(target)}`;
  const buf = await getURL(u); if (!buf) return { error: true };
  try { return JSON.parse(buf.toString()); } catch (e) { return { error: true }; }
}

// ---------- monitor de áudio (abaixar quando outro programa tocar) ----------
let audioNow = [], audioProc = null, audioOk = false;
function startAudioMonitor() {
  if (process.platform !== 'win32') return;
  const script = path.join(DIR, 'audio-monitor.ps1');
  try {
    audioProc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', script], { windowsHide: true });
  } catch (e) { return; }
  let buf = '';
  audioProc.stdout.on('data', (d) => {
    buf += d.toString('utf8');
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (line.startsWith('[')) { try { audioNow = JSON.parse(line); audioOk = true; } catch (e) {} }
    }
  });
  audioProc.on('exit', () => { audioProc = null; if (!quitting) setTimeout(startAudioMonitor, 5000); });
}
function duckState() {
  if (!audioOk) return { ok: false, playing: [] };
  const mine = new Set(app.getAppMetrics().map((m) => m.pid)); mine.add(process.pid);
  const seen = new Set(), playing = [];
  for (const a of audioNow) {
    if (mine.has(a.pid)) continue;
    const name = a.app || `pid ${a.pid}`;
    if (seen.has(name)) continue; seen.add(name);
    playing.push({ pid: a.pid, app: name, bundle: '' });
  }
  return { ok: true, v: 1, playing };
}

// ---------- servidor local ----------
const files = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/widget': ['widget.html', 'text/html; charset=utf-8']
};
// Volta do login do Spotify (http://127.0.0.1:17846/callback?code=…&state=…)
let spCodeQuery = '';
const SP_CALLBACK_HTML = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>SpotLo-fi</title></head><body style='margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:-apple-system,system-ui,Segoe UI,Roboto,sans-serif;background:#15121d;color:#f5f5f7;text-align:center'><div style='padding:24px'><h2 id='t' style='margin:0 0 8px'>Spotify conectado!</h2><p style='opacity:.7;margin:0 0 18px'>Pode fechar esta aba e voltar para o SpotLo-fi.</p><a id='b' href='#' style='display:inline-block;padding:12px 24px;border-radius:999px;background:#1ed760;color:#000;font-weight:700;text-decoration:none'>Voltar para o SpotLo-fi</a></div><script>var q=location.search.slice(1),u='spotlofi://spauth?'+q;if(/(^|&)error=/.test(q)){document.getElementById('t').textContent='Login cancelado';}document.getElementById('b').href=u;setTimeout(function(){location.href=u},600);</script></body></html>";
function startServer() {
  return new Promise((resolve) => {
    const srv = http.createServer(async (req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1');
      const send = (code, type, body) => { res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(body); };
      const json = (o) => send(200, 'application/json', JSON.stringify(o));
      const q = Object.fromEntries(u.searchParams.entries());
      try {
        if (files[u.pathname]) return send(200, files[u.pathname][1], fs.readFileSync(path.join(DIR, files[u.pathname][0])));
        if (u.pathname === '/callback') { if (u.search.length > 1) spCodeQuery = u.search.slice(1); return send(200, 'text/html; charset=utf-8', SP_CALLBACK_HTML); }
        if (u.pathname === '/__api/spcode') { const v = spCodeQuery; spCodeQuery = ''; return json({ q: v }); }
        if (u.pathname === '/__duck/state') return json(duckState());
        if (u.pathname === '/__api/ytsearch') return json(await ytSearch(q.q || '', q.kind || ''));
        if (u.pathname === '/__api/ytraw') {
          const p = q.p || ''; if (!p.startsWith('/')) return json({ ok: false });
          const buf = q.b ? await postURL('https://www.youtube.com' + p, q.b, { 'Content-Type': 'application/json', Cookie: 'CONSENT=YES+1; SOCS=CAI' })
                          : await getURL('https://www.youtube.com' + p, { Cookie: 'CONSENT=YES+1; SOCS=CAI' });
          return json(buf ? { ok: true, body: buf.toString('utf8') } : { ok: false });
        }
        if (u.pathname === '/__api/spembed') return json(await spEmbed(q.kind || 'playlist', q.id || ''));
        if (u.pathname === '/__api/spsearch') return json(await spSearch(q.q || '', q.cid || '', q.cs || ''));
        if (u.pathname === '/__api/oembed') return json(await oembed(q.url || ''));
        if (u.pathname === '/favicon.ico') return send(200, 'image/x-icon', fs.readFileSync(ICON));
        send(404, 'text/plain', '404');
      } catch (e) { send(500, 'application/json', JSON.stringify({ ok: false, error: String(e) })); }
    });
    let p = PORT_PREFERRED;
    srv.on('error', () => { p++; if (p > PORT_PREFERRED + 5) p = 0; srv.listen(p, '127.0.0.1'); });
    srv.on('listening', () => resolve(srv.address().port));
    srv.listen(p, '127.0.0.1');
  });
}

// ---------- janela principal ----------
function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 720, minHeight: 520,
    backgroundColor: '#08080d', icon: ICON, title: 'SpotLo-fi', show: false,
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#00000000', symbolColor: '#f5f5f7', height: 44 },
    webPreferences: { preload: path.join(DIR, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' }
  });
  restoreBounds();
  win.once('ready-to-show', () => win.show());
  win.loadURL(`http://127.0.0.1:${port}/`);
  // fechar a janela principal fecha o SpotLo-fi inteiro (nada fica rodando escondido)
  win.on('close', () => {
    if (isMini && savedBounds) { try { fs.writeFileSync(boundsFile(), JSON.stringify(savedBounds)); } catch (e) {} } else saveBounds();
    if (!quitting) { quitting = true; setImmediate(() => app.quit()); }
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    const host = (() => { try { return new URL(url).host; } catch (e) { return ''; } })();
    if (!url || url === 'about:blank' || /(^|\.)accounts\.spotify\.com$|(^|\.)accounts\.google\.com$|(^|\.)appleid\.apple\.com$|(^|\.)facebook\.com$|(^|\.)challenge\.spotify\.com$/.test(host)) {
      return { action: 'allow', overrideBrowserWindowOptions: { width: 480, height: 720, icon: ICON, autoHideMenuBar: true } };
    }
    shell.openExternal(url); return { action: 'deny' };
  });
  win.webContents.on('did-create-window', (child) => child.on('closed', () => toPage({ spotifyLogin: true })));
}
const boundsFile = () => path.join(app.getPath('userData'), 'window.json');
function saveBounds() { try { if (win && !isMini) fs.writeFileSync(boundsFile(), JSON.stringify(win.getNormalBounds())); } catch (e) {} }
function restoreBounds() {
  try {
    const b = JSON.parse(fs.readFileSync(boundsFile(), 'utf8'));
    const area = screen.getDisplayMatching(b).workArea;
    if (b.x >= area.x - 50 && b.y >= area.y - 50 && b.width > 600) win.setBounds(b);
  } catch (e) {}
}
function showMain() { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); }

// ---------- modo mini ----------
function toggleMini() {
  if (!win) return;
  if (win.isFullScreen()) { win.setFullScreen(false); setTimeout(toggleMini, 700); return; }
  showMain();
  isMini = !isMini;
  toPage({ mini: isMini });
  if (isMini) {
    savedBounds = win.getBounds();
    win.setAlwaysOnTop(true, 'floating');
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    win.setSkipTaskbar(false);
    try { win.setTitleBarOverlay({ color: '#00000000', symbolColor: '#ffffff', height: 26 }); } catch (e) {}
    applyMiniLayout(true);
  } else {
    win.setAlwaysOnTop(false);
    win.setVisibleOnAllWorkspaces(false);
    win.setAspectRatio(0);
    win.setMinimumSize(720, 520);
    win.setMaximumSize(10000, 10000);
    try { win.setTitleBarOverlay({ color: '#00000000', symbolColor: '#f5f5f7', height: 44 }); } catch (e) {}
    if (savedBounds) win.setBounds(savedBounds, true);
  }
  buildTrayMenu();
}
function applyMiniLayout(entering) {
  const area = screen.getDisplayMatching(win.getBounds()).workArea;
  const cur = win.getBounds();
  let w, h;
  if (miniKind === 'sp') {
    win.setAspectRatio(0); win.setMinimumSize(300, 152); win.setMaximumSize(900, 352);
    w = entering ? 420 : Math.max(300, Math.min(cur.width, 900)); h = 152;
  } else {
    win.setMinimumSize(288, 162); win.setMaximumSize(1600, 900); win.setAspectRatio(16 / 9);
    w = entering ? 480 : Math.max(320, Math.min(cur.width, 1600)); h = Math.round(w * 9 / 16);
  }
  let x = entering ? area.x + area.width - w - 20 : cur.x + cur.width - w;
  let y = entering ? area.y + area.height - h - 20 : cur.y + cur.height - h;
  x = Math.min(Math.max(x, area.x), area.x + area.width - w);
  y = Math.min(Math.max(y, area.y), area.y + area.height - h);
  win.setBounds({ x, y, width: w, height: h }, true);
}

// ---------- widget ----------
function showWidget(on, onTop) {
  widgetOnTop = !!onTop;
  if (!on) { if (widget && !widget.isDestroyed()) widget.hide(); return; }
  if (!widget || widget.isDestroyed()) {
    const area = screen.getPrimaryDisplay().workArea;
    let pos = { x: area.x + area.width - 320, y: area.y + 20 };
    try { pos = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'widget.json'), 'utf8')); } catch (e) {}
    widget = new BrowserWindow({
      width: 300, height: 176, x: pos.x, y: pos.y, frame: false, resizable: false, skipTaskbar: true,
      transparent: true, backgroundColor: '#00000000', hasShadow: true, show: false, icon: ICON, title: 'SpotLo-fi widget',
      maximizable: false, minimizable: false, fullscreenable: false,
      webPreferences: { preload: path.join(DIR, 'preload-widget.js'), contextIsolation: true, nodeIntegration: false }
    });
    try { widget.setBackgroundMaterial('acrylic'); } catch (e) {}
    widget.loadURL(`http://127.0.0.1:${port}/widget`);
    widget.once('ready-to-show', () => { widget.showInactive(); pushWidget(); });
    widget.on('moved', () => { try { const b = widget.getBounds(); fs.writeFileSync(path.join(app.getPath('userData'), 'widget.json'), JSON.stringify({ x: b.x, y: b.y })); } catch (e) {} });
  } else widget.showInactive();
  widget.setAlwaysOnTop(widgetOnTop, 'floating');
  widget.setVisibleOnAllWorkspaces(true);
}
function pushWidget() {
  if (!widget || widget.isDestroyed() || !widget.isVisible()) return;
  widget.webContents.executeJavaScript(`window.upd&&window.upd(${JSON.stringify(widgetState)})`).catch(() => {});
}

// ---------- ícone perto do relógio ----------
function buildTrayMenu() {
  if (!tray) return;
  const items = [
    { label: np.title ? (np.title.length > 48 ? np.title.slice(0, 47) + '…' : np.title) : 'Nada tocando', enabled: false },
    ...(np.artist ? [{ label: np.artist, enabled: false }] : []),
    { type: 'separator' },
    { label: np.playing ? 'Pausar' : 'Tocar', click: () => toPage({ action: 'toggle' }) },
    { label: 'Próxima', click: () => toPage({ action: 'next' }) },
    { label: 'Anterior', click: () => toPage({ action: 'prev' }) },
    ...(sceneNames.length ? [{ type: 'separator' }, { label: 'Cenas', submenu: sceneNames.map((n, i) => ({ label: n, click: () => toPage({ action: 'scene', index: i }) })) }] : []),
    { type: 'separator' },
    { label: isMini ? 'Sair do modo mini' : 'Modo mini', click: toggleMini },
    { label: 'Mostrar/ocultar widget', click: () => toPage({ action: 'widgetToggle' }) },
    { label: 'Entrar no Spotify…', click: openSpotifyLogin },
    { label: 'Verificar atualizações…', click: () => { showMain(); toPage({ action: 'updatePanel' }); checkUpdate(true); } },
    { label: 'Mostrar SpotLo-fi', click: showMain },
    { type: 'separator' },
    { label: 'Sair do SpotLo-fi', click: () => { quitting = true; app.quit(); } }
  ];
  tray.setContextMenu(Menu.buildFromTemplate(items));
  tray.setToolTip(np.title ? `${np.title} — SpotLo-fi` : 'SpotLo-fi');
}
function openSpotifyLogin() {
  const w = new BrowserWindow({ width: 480, height: 720, icon: ICON, autoHideMenuBar: true, title: 'Entrar no Spotify — feche quando terminar' });
  w.loadURL('https://accounts.spotify.com/login?continue=https%3A%2F%2Fopen.spotify.com%2F');
  w.on('closed', () => toPage({ spotifyLogin: true }));
}

// ---------- atalhos globais e teclas de mídia ----------
let hotkeyMap = {};
function accel(combo) {
  const parts = String(combo || '').toLowerCase().split('+').map((s) => s.trim()).filter(Boolean);
  if (!parts.length) return null;
  const key = parts.pop();
  const mods = parts.map((p) => ({ ctrl: 'Control', control: 'Control', opt: 'Alt', option: 'Alt', alt: 'Alt', cmd: 'Super', command: 'Super', meta: 'Super', shift: 'Shift' })[p]).filter(Boolean);
  const k = ({ space: 'Space', return: 'Return', enter: 'Return', left: 'Left', right: 'Right', up: 'Up', down: 'Down', '=': '=', '-': '-', ',': ',', '.': '.', '/': '/', ';': ';', "'": "'", '[': '[', ']': ']', '\\': '\\' })[key] || key.toUpperCase();
  if (!mods.length && !/^F\d+$/.test(k)) return null;
  return [...mods, k].join('+');
}
function applyHotkeys(map) {
  for (const a of Object.values(hotkeyMap)) { try { globalShortcut.unregister(a); } catch (e) {} }
  hotkeyMap = {};
  const failed = [];
  for (const [action, combo] of Object.entries(map || {})) {
    if (action === 'voice') continue;
    const a = accel(combo); if (!a) continue;
    let ok = false;
    try { ok = globalShortcut.register(a, () => hotkeyFired(action)); } catch (e) {}
    if (ok) hotkeyMap[action] = a; else failed.push(action);
  }
  toPage({ hotkeysFailed: failed });
}
function hotkeyFired(action) {
  if (action === 'show') return showMain();
  if (action === 'mini') return toggleMini();
  if (action === 'widget') return toPage({ action: 'widgetToggle' });
  toPage({ action });
}
function registerMediaKeys() {
  const m = { MediaPlayPause: 'toggle', MediaNextTrack: 'next', MediaPreviousTrack: 'prev', MediaStop: 'pause' };
  for (const [k, a] of Object.entries(m)) { try { globalShortcut.register(k, () => toPage({ action: a })); } catch (e) {} }
}

// ---------- minimizar as outras janelas (bloquear distrações) ----------
function shellApp(method) {
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `(New-Object -ComObject Shell.Application).${method}()`], { windowsHide: true }, () => {
    if (method === 'MinimizeAll' && win) setTimeout(() => { win.restore(); win.showInactive(); }, 400);
  });
}

// ---------- atualização automática (GitHub) ----------
let latest = null;
const isNewer = (a, b) => { const pa = a.split('.').map(Number), pb = b.split('.').map(Number); for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x > y; } return false; };
async function checkUpdate(manual) {
  const buf = await getURL(`https://raw.githubusercontent.com/${UPDATE_REPO}/main/latest.json?t=${Date.now()}`);
  let j = null; try { j = JSON.parse(buf.toString()); } catch (e) {}
  const w = j && (j.win || null);
  if (!w || !w.version) { if (manual) toPage({ update: { state: 'error', message: 'Não consegui verificar agora.' } }); return; }
  latest = w;
  if (isNewer(w.version, APP_VERSION)) toPage({ update: { state: 'available', version: w.version, notes: w.notes || j.notes || '' } });
  else if (manual) toPage({ update: { state: 'current', version: APP_VERSION } });
}
// Atualização: baixa a pasta "app" nova para %APPDATA%\SpotLo-fi\updates\<versão> e reabre.
// Nada do programa instalado é apagado ou trocado com ele aberto (o boot.js escolhe a versão mais nova).
function findAppDir(dir, depth = 0) {
  if (fs.existsSync(path.join(dir, 'main.js')) && fs.existsSync(path.join(dir, 'package.json'))) return dir;
  if (depth > 3) return null;
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) if (d.isDirectory()) { const r = findAppDir(path.join(dir, d.name), depth + 1); if (r) return r; }
  return null;
}
function unzip(zip, dest) {
  return new Promise((resolve) => {
    fs.mkdirSync(dest, { recursive: true });
    const ok = () => { try { return !!findAppDir(dest); } catch (e) { return false; } };
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
      'Expand-Archive -LiteralPath $env:SL_ZIP -DestinationPath $env:SL_DEST -Force'],
      { env: { ...process.env, SL_ZIP: zip, SL_DEST: dest }, windowsHide: true, timeout: 180000 }, (err) => {
        if (!err && ok()) return resolve(true);
        const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
        execFile(tar, ['-xf', zip, '-C', dest], { windowsHide: true, timeout: 180000 }, () => resolve(ok()));
      });
  });
}
let updating = false;
async function installUpdate() {
  if (updating) return;
  if (!latest || !latest.zip) return checkUpdate(true);
  updating = true;
  const fail = (m) => { updating = false; toPage({ update: { state: 'error', message: m } }); };
  try {
    toPage({ update: { state: 'downloading' } });
    const url = latest.zip.startsWith('http') ? latest.zip : `https://raw.githubusercontent.com/${UPDATE_REPO}/main/${latest.zip}`;
    const buf = await getURL(url);
    if (!buf || buf.length < 1000) return fail('Não consegui baixar a atualização. Confira a internet e tente de novo.');
    toPage({ update: { state: 'installing' } });
    const root = path.join(app.getPath('userData'), 'updates');
    const work = path.join(root, 'baixando');
    fs.rmSync(work, { recursive: true, force: true }); fs.mkdirSync(work, { recursive: true });
    const zip = path.join(work, 'update.zip'); fs.writeFileSync(zip, buf);
    if (!(await unzip(zip, path.join(work, 'x')))) return fail('Não consegui abrir o arquivo da atualização.');
    const src = findAppDir(path.join(work, 'x'));
    let v = '';
    try { v = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8')).version; } catch (e) {}
    if (!v || !isNewer(v, APP_VERSION)) return fail('A atualização baixada não é mais nova que esta versão.');
    const dest = path.join(root, v);
    fs.rmSync(dest, { recursive: true, force: true });
    fs.renameSync(src, dest);
    try { fs.rmSync(work, { recursive: true, force: true }); } catch (e) {}
    // reabre já na versão nova
    quitting = true;
    try { if (audioProc) audioProc.kill(); } catch (e) {}
    try { saveBounds(); } catch (e) {}
    try { if (tray) tray.destroy(); } catch (e) {}
    app.relaunch({ args: process.argv.slice(1).filter((a) => a !== '--after-update').concat('--after-update') });
    setTimeout(() => app.exit(0), 300);
  } catch (e) {
    fail('Erro ao instalar a atualização: ' + (e && e.message ? e.message : e));
  }
}

ipcMain.on('appVersion', (e) => { e.returnValue = APP_VERSION; });
// ---------- mensagens da página ----------
ipcMain.on('cmd', (_e, body) => {
  if (!body || typeof body !== 'object') return;
  const cmd = body.cmd;
  switch (cmd) {
    case 'ready':
      pageReady = true;
      toPage({ aiStatus: 'web', version: APP_VERSION });
      for (const u of pendingURLs.splice(0)) toPage({ url: u });
      break;
    case 'state':
      for (const k of ['title', 'artist', 'playing', 'duration', 'position', 'thumb', 'c1', 'c2', 'task', 'pomo']) if (k in body) widgetState[k] = body[k];
      if (Array.isArray(body.scenes)) sceneNames = body.scenes;
      { const changed = body.title !== np.title || body.playing !== np.playing || Array.isArray(body.scenes);
        np = { title: body.title || '', artist: body.artist || '', playing: !!body.playing, thumb: body.thumb || '' };
        if (changed) buildTrayMenu(); }
      pushWidget();
      break;
    case 'mini': toggleMini(); break;
    case 'miniKind': {
      const k = body.kind === 'sp' ? 'sp' : 'yt';
      if (k !== miniKind) { miniKind = k; if (isMini) applyMiniLayout(false); }
      break;
    }
    case 'fullscreen': win.setFullScreen(!win.isFullScreen()); break;
    case 'saveFile':
      dialog.showSaveDialog(win, { defaultPath: body.name || 'SpotLo-fi-backup.json', filters: [{ name: 'JSON', extensions: ['json'] }] }).then((r) => {
        if (r.canceled || !r.filePath) return;
        try { fs.writeFileSync(r.filePath, body.content || '', 'utf8'); toPage({ toast: 'Arquivo salvo ✓' }); } catch (e) { toPage({ toast: 'Não consegui salvar o arquivo.' }); }
      });
      break;
    case 'openFile':
      dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'JSON', extensions: ['json'] }] }).then((r) => {
        if (r.canceled || !r.filePaths[0]) return;
        try { toPage({ importData: fs.readFileSync(r.filePaths[0], 'utf8') }); } catch (e) { toPage({ toast: 'Não consegui ler esse arquivo.' }); }
      });
      break;
    case 'loginItem':
      if (typeof body.on === 'boolean') app.setLoginItemSettings({ openAtLogin: body.on, args: ['--hidden'] });
      toPage({ loginItem: app.getLoginItemSettings().openAtLogin });
      break;
    case 'spotifyLogin': openSpotifyLogin(); break;
    case 'open': if (/^https?:\/\//.test(body.url || '')) shell.openExternal(body.url); break;
    case 'copy': clipboard.writeText(String(body.text || '')); break;
    case 'hotkeys': applyHotkeys(body.map); break;
    case 'widget':
      if (typeof body.on === 'boolean') showWidget(body.on, body.onTop);
      else if (typeof body.onTop === 'boolean' && widget && !widget.isDestroyed()) { widgetOnTop = body.onTop; widget.setAlwaysOnTop(widgetOnTop, 'floating'); }
      break;
    case 'shortcutsList': toPage({ shortcuts: [] }); break;
    case 'hideOthers': shellApp('MinimizeAll'); break;
    case 'unhideOthers': shellApp('UndoMinimizeAll'); break;
    case 'updateCheck': checkUpdate(true); break;
    case 'updateInstall': installUpdate(); break;
    default: break;   // ai, voice, speak etc. não existem na versão do Windows
  }
});
ipcMain.on('widget', (_e, body) => {
  const a = body && body.action;
  if (!a) return;
  if (a === 'ready') return pushWidget();
  if (a === 'show') return showMain();
  toPage({ action: a });
});

// ---------- início ----------
app.whenReady().then(async () => {
  // componente de proteção de conteúdo (Widevine) para o Spotify tocar inteiro
  try { if (components && components.whenReady) await Promise.race([components.whenReady(), new Promise((r) => setTimeout(r, 15000))]); } catch (e) {}

  session.defaultSession.setPermissionRequestHandler((wc, permission, cb, details) => {
    const origin = (details && (details.requestingUrl || details.securityOrigin)) || '';
    if (permission === 'media' && origin.startsWith('http://127.0.0.1')) return cb(true);
    if (['clipboard-sanitized-write', 'fullscreen', 'notifications', 'protected-media-identifier'].includes(permission)) return cb(true);
    cb(false);
  });
  session.defaultSession.setPermissionCheckHandler((wc, permission, origin) => {
    if (permission === 'media') return String(origin || '').startsWith('http://127.0.0.1');
    return true;
  });

  port = await startServer();
  createWindow();
  if (process.argv.includes('--hidden')) win.once('ready-to-show', () => win.minimize());

  tray = new Tray(nativeImage.createFromPath(path.join(DIR, 'tray.png')));
  tray.on('click', showMain);
  buildTrayMenu();

  registerMediaKeys();
  startAudioMonitor();
  setTimeout(() => checkUpdate(false), 4000);
  setInterval(() => checkUpdate(false), 6 * 3600 * 1000);

  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'SpotLo-fi', submenu: [
      { label: 'Modo mini', accelerator: 'Ctrl+Shift+M', click: toggleMini },
      { label: 'Tela cheia', accelerator: 'F11', click: () => win.setFullScreen(!win.isFullScreen()) },
      { label: 'Recarregar', accelerator: 'Ctrl+R', click: () => win.reload() },
      { label: 'Ferramentas do desenvolvedor', accelerator: 'Ctrl+Shift+I', click: () => win.webContents.toggleDevTools() },
      { type: 'separator' },
      { label: 'Sair', accelerator: 'Ctrl+Q', click: () => { quitting = true; app.quit(); } }
    ] },
    { label: 'Editar', submenu: [{ role: 'undo', label: 'Desfazer' }, { role: 'redo', label: 'Refazer' }, { type: 'separator' }, { role: 'cut', label: 'Recortar' }, { role: 'copy', label: 'Copiar' }, { role: 'paste', label: 'Colar' }, { role: 'selectAll', label: 'Selecionar tudo' }] }
  ]));
});

app.on('before-quit', () => { quitting = true; saveBounds(); });
app.on('will-quit', () => { globalShortcut.unregisterAll(); if (audioProc) try { audioProc.kill(); } catch (e) {} });
app.on('window-all-closed', () => { quitting = true; app.quit(); });
