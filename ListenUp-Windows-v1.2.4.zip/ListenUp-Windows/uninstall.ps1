﻿# Desinstala o ListenUp (suas músicas e playlists em %APPDATA%\SpotLo-fi ficam guardadas)
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$r = [System.Windows.Forms.MessageBox]::Show('Desinstalar o ListenUp? Suas músicas e playlists ficam guardadas caso você instale de novo.', 'SpotLo-fi', 'YesNo', 'Question')
if ($r -ne 'Yes') { exit }

Get-Process -Name 'SpotLo-fi' | Stop-Process -Force
Start-Sleep -Milliseconds 800
$Dest = Join-Path $env:LOCALAPPDATA 'Programs\SpotLo-fi'
foreach ($dir in @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('Desktop'))) {
  Remove-Item (Join-Path $dir 'SpotLo-fi.lnk') -Force
  Remove-Item (Join-Path $dir 'ListenUp.lnk') -Force
}
Remove-Item 'HKCU:\Software\Classes\spotlofi' -Recurse -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SpotLo-fi' -Recurse -Force
Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'SpotLo-fi' -Force
Remove-Item (Join-Path $env:LOCALAPPDATA 'SpotLo-fi-installer') -Recurse -Force
# apaga a pasta do programa depois que este script terminar
Start-Process -FilePath 'cmd.exe' -ArgumentList "/c timeout /t 2 >nul & rmdir /s /q `"$Dest`"" -WindowStyle Hidden
[System.Windows.Forms.MessageBox]::Show('ListenUp desinstalado.', 'ListenUp') | Out-Null
