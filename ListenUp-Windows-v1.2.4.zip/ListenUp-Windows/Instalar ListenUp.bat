@echo off
chcp 65001 >nul
title Instalando o ListenUp
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo   Algo deu errado. Tire um print desta janela e mande no chat.
  echo.
  pause
  exit /b 1
)
timeout /t 4 >nul
