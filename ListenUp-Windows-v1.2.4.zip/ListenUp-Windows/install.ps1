﻿# Instalador do ListenUp para Windows (nomes internos "SpotLo-fi" mantidos para não perder a biblioteca)
# - baixa o Electron (motor do app) direto do GitHub e confere a assinatura do arquivo
# - instala em %LOCALAPPDATA%\Programs\SpotLo-fi (não precisa de administrador)
# - cria atalhos no Menu Iniciar e na Área de Trabalho, registra links spotlofi:// e o desinstalador
# Suas músicas e playlists ficam em %APPDATA%\SpotLo-fi e não são apagadas ao reinstalar.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Version     = '1.2.4'
$ElectronVer = '33.2.1+wvcus'
$ZipName     = 'electron-v33.2.1+wvcus-win32-x64.zip'
$ZipUrl      = 'https://github.com/castlabs/electron-releases/releases/download/v33.2.1%2Bwvcus/electron-v33.2.1%2Bwvcus-win32-x64.zip'
$ZipSha256   = 'f5854320a3a2f675b69855e356932e45e5608aa056bc001ead124d6c054ffb40'

$Here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest    = Join-Path $env:LOCALAPPDATA 'Programs\SpotLo-fi'
$Exe     = Join-Path $Dest 'SpotLo-fi.exe'
$AppDir  = Join-Path $Dest 'resources\app'
$Cache   = Join-Path $env:LOCALAPPDATA 'SpotLo-fi-installer'

function Step($t) { Write-Host "  > $t" -ForegroundColor Cyan }

Write-Host ''
Write-Host "  ListenUp $Version para Windows" -ForegroundColor Green
Write-Host ''

if (-not [Environment]::Is64BitOperatingSystem) { throw 'O ListenUp precisa do Windows de 64 bits.' }
if (-not (Test-Path (Join-Path $Here 'app\main.js'))) { throw 'Não achei a pasta "app" ao lado do instalador. Descompacte o zip inteiro antes de instalar.' }

# fecha o app se estiver aberto
Get-Process -Name 'SpotLo-fi' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 800

# 1) motor do app (Electron), só se ainda não estiver instalado nesta versão
$stamp = Join-Path $Dest 'engine.txt'
$haveEngine = (Test-Path $Exe) -and (Test-Path $stamp) -and ((Get-Content $stamp -Raw).Trim() -eq $ElectronVer)
if (-not $haveEngine) {
  New-Item -ItemType Directory -Force -Path $Cache | Out-Null
  $zip = Join-Path $Cache $ZipName
  $ok = $false
  if (Test-Path $zip) { $ok = ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -eq $ZipSha256) }
  if (-not $ok) {
    Step 'Baixando o motor do app (cerca de 110 MB, só na primeira vez)...'
    $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
    if (Test-Path $curl) { & $curl -L --fail --retry 3 --progress-bar -o $zip $ZipUrl; if ($LASTEXITCODE -ne 0) { throw 'Falha no download. Verifique a internet e rode de novo.' } }
    else { Invoke-WebRequest -Uri $ZipUrl -OutFile $zip -UseBasicParsing }
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
    if ($hash -ne $ZipSha256) { Remove-Item $zip -Force; throw 'O download veio corrompido. Rode o instalador de novo.' }
  }
  Step 'Instalando o motor...'
  if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $Dest)
  Rename-Item -LiteralPath (Join-Path $Dest 'electron.exe') -NewName 'SpotLo-fi.exe'
  $def = Join-Path $Dest 'resources\default_app.asar'
  if (Test-Path $def) { Remove-Item $def -Force }
  Set-Content -Path $stamp -Value $ElectronVer -Encoding ASCII
}

# 2) o app em si
Step 'Copiando o ListenUp...'
if (Test-Path $AppDir) { Remove-Item $AppDir -Recurse -Force }
Copy-Item -LiteralPath (Join-Path $Here 'app') -Destination $AppDir -Recurse -Force
Get-ChildItem $AppDir -Recurse -File | ForEach-Object { $_.IsReadOnly = $false }
Copy-Item -LiteralPath (Join-Path $Here 'uninstall.ps1') -Destination (Join-Path $Dest 'uninstall.ps1') -Force
$Icon = Join-Path $AppDir 'icon.ico'

# 3) atalhos
Step 'Criando atalhos...'
$ws = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('Desktop'))) {
  Remove-Item (Join-Path $dir 'SpotLo-fi.lnk') -Force -ErrorAction SilentlyContinue
  $lnk = $ws.CreateShortcut((Join-Path $dir 'ListenUp.lnk'))
  $lnk.TargetPath = $Exe
  $lnk.WorkingDirectory = $Dest
  $lnk.IconLocation = "$Icon,0"
  $lnk.Description = 'ListenUp'
  $lnk.Save()
}

# 4) links spotlofi:// e desinstalador (só para este usuário)
Step 'Registrando links spotlofi:// ...'
$cls = 'HKCU:\Software\Classes\spotlofi'
New-Item -Path "$cls\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path $cls -Name '(default)' -Value 'URL:ListenUp'
Set-ItemProperty -Path $cls -Name 'URL Protocol' -Value ''
New-Item -Path "$cls\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$cls\DefaultIcon" -Name '(default)' -Value "`"$Icon`",0"
Set-ItemProperty -Path "$cls\shell\open\command" -Name '(default)' -Value "`"$Exe`" `"%1`""

$un = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SpotLo-fi'
New-Item -Path $un -Force | Out-Null
Set-ItemProperty -Path $un -Name 'DisplayName' -Value 'ListenUp'
Set-ItemProperty -Path $un -Name 'DisplayVersion' -Value $Version
Set-ItemProperty -Path $un -Name 'Publisher' -Value 'ListenUp'
Set-ItemProperty -Path $un -Name 'DisplayIcon' -Value $Icon
Set-ItemProperty -Path $un -Name 'InstallLocation' -Value $Dest
Set-ItemProperty -Path $un -Name 'NoModify' -Value 1 -Type DWord
Set-ItemProperty -Path $un -Name 'NoRepair' -Value 1 -Type DWord
Set-ItemProperty -Path $un -Name 'UninstallString' -Value "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $Dest 'uninstall.ps1')`""

Write-Host ''
Write-Host '  Pronto! O ListenUp foi instalado. Abrindo...' -ForegroundColor Green
Write-Host '  (Ele aparece no Menu Iniciar e na Área de Trabalho.)'
Write-Host ''
Start-Process -FilePath $Exe -WorkingDirectory $Dest
